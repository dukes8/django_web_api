from django.apps import AppConfig


class DjappConfig(AppConfig):
    name = 'djapp'
